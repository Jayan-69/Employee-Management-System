﻿namespace Employee_System
{
    partial class sal_dept
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnexit = new System.Windows.Forms.Button();
            this.btnAddNew = new System.Windows.Forms.Button();
            this.btnsalcal = new System.Windows.Forms.Button();
            this.btnMainMenu = new System.Windows.Forms.Button();
            this.lblheading = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnexit
            // 
            this.btnexit.BackColor = System.Drawing.Color.Red;
            this.btnexit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnexit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnexit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnexit.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnexit.Location = new System.Drawing.Point(597, 401);
            this.btnexit.Name = "btnexit";
            this.btnexit.Size = new System.Drawing.Size(120, 28);
            this.btnexit.TabIndex = 4;
            this.btnexit.Text = "Exit";
            this.btnexit.UseVisualStyleBackColor = false;
            this.btnexit.Click += new System.EventHandler(this.btnexit_Click);
            // 
            // btnAddNew
            // 
            this.btnAddNew.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.btnAddNew.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddNew.Font = new System.Drawing.Font("Elephant", 12F);
            this.btnAddNew.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnAddNew.Location = new System.Drawing.Point(59, 147);
            this.btnAddNew.Name = "btnAddNew";
            this.btnAddNew.Size = new System.Drawing.Size(203, 171);
            this.btnAddNew.TabIndex = 6;
            this.btnAddNew.Text = "Add New Employee Salary Details";
            this.btnAddNew.UseVisualStyleBackColor = false;
            this.btnAddNew.Click += new System.EventHandler(this.btnAddNew_Click);
            // 
            // btnsalcal
            // 
            this.btnsalcal.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.btnsalcal.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnsalcal.Font = new System.Drawing.Font("Elephant", 12F);
            this.btnsalcal.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnsalcal.Location = new System.Drawing.Point(514, 147);
            this.btnsalcal.Name = "btnsalcal";
            this.btnsalcal.Size = new System.Drawing.Size(203, 171);
            this.btnsalcal.TabIndex = 7;
            this.btnsalcal.Text = "Calculate Salary of an Existing Employee";
            this.btnsalcal.UseVisualStyleBackColor = false;
            this.btnsalcal.Click += new System.EventHandler(this.btnsalcal_Click);
            // 
            // btnMainMenu
            // 
            this.btnMainMenu.BackColor = System.Drawing.Color.Blue;
            this.btnMainMenu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMainMenu.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnMainMenu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMainMenu.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnMainMenu.Location = new System.Drawing.Point(59, 401);
            this.btnMainMenu.Name = "btnMainMenu";
            this.btnMainMenu.Size = new System.Drawing.Size(120, 28);
            this.btnMainMenu.TabIndex = 9;
            this.btnMainMenu.Text = "Main Menu";
            this.btnMainMenu.UseVisualStyleBackColor = false;
            this.btnMainMenu.Click += new System.EventHandler(this.btnMainMenu_Click);
            // 
            // lblheading
            // 
            this.lblheading.AutoSize = true;
            this.lblheading.BackColor = System.Drawing.Color.Gold;
            this.lblheading.Font = new System.Drawing.Font("Rockwell", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblheading.Location = new System.Drawing.Point(218, 39);
            this.lblheading.Name = "lblheading";
            this.lblheading.Size = new System.Drawing.Size(340, 43);
            this.lblheading.TabIndex = 11;
            this.lblheading.Text = "Salary Department";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.Font = new System.Drawing.Font("Elephant", 12F);
            this.button1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button1.Location = new System.Drawing.Point(287, 147);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(203, 171);
            this.button1.TabIndex = 12;
            this.button1.Text = "Update or Delete Existing Employee Salary information";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // sal_dept
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Snow;
            this.BackgroundImage = global::Employee_System.Properties.Resources.istockphoto_1387809317_612x612;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(781, 461);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lblheading);
            this.Controls.Add(this.btnMainMenu);
            this.Controls.Add(this.btnsalcal);
            this.Controls.Add(this.btnAddNew);
            this.Controls.Add(this.btnexit);
            this.Name = "sal_dept";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Salary Department";
            this.Load += new System.EventHandler(this.sal_dept_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnexit;
        private System.Windows.Forms.Button btnAddNew;
        private System.Windows.Forms.Button btnsalcal;
        private System.Windows.Forms.Button btnMainMenu;
        private System.Windows.Forms.Label lblheading;
        private System.Windows.Forms.Button button1;
    }
}