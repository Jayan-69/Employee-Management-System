﻿namespace Employee_System
{
    partial class hrdept
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnexit = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btnnewemployee = new System.Windows.Forms.Button();
            this.btnexisting = new System.Windows.Forms.Button();
            this.lblheading = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnexit
            // 
            this.btnexit.BackColor = System.Drawing.Color.Red;
            this.btnexit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnexit.Font = new System.Drawing.Font("Microsoft Tai Le", 14F, System.Drawing.FontStyle.Bold);
            this.btnexit.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnexit.Location = new System.Drawing.Point(614, 380);
            this.btnexit.Name = "btnexit";
            this.btnexit.Size = new System.Drawing.Size(111, 28);
            this.btnexit.TabIndex = 4;
            this.btnexit.Text = "Exit";
            this.btnexit.UseVisualStyleBackColor = false;
            this.btnexit.Click += new System.EventHandler(this.btnexit_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Blue;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("Microsoft Tai Le", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button1.Location = new System.Drawing.Point(63, 380);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(145, 28);
            this.button1.TabIndex = 5;
            this.button1.Text = "Main Menu";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnnewemployee
            // 
            this.btnnewemployee.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnnewemployee.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnnewemployee.Font = new System.Drawing.Font("Microsoft Tai Le", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnnewemployee.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnnewemployee.Location = new System.Drawing.Point(208, 140);
            this.btnnewemployee.Name = "btnnewemployee";
            this.btnnewemployee.Size = new System.Drawing.Size(186, 153);
            this.btnnewemployee.TabIndex = 6;
            this.btnnewemployee.Text = "Add New Employee";
            this.btnnewemployee.UseVisualStyleBackColor = false;
            this.btnnewemployee.Click += new System.EventHandler(this.btnnewemployee_Click);
            // 
            // btnexisting
            // 
            this.btnexisting.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnexisting.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnexisting.Font = new System.Drawing.Font("Microsoft Tai Le", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnexisting.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnexisting.Location = new System.Drawing.Point(419, 140);
            this.btnexisting.Name = "btnexisting";
            this.btnexisting.Size = new System.Drawing.Size(179, 153);
            this.btnexisting.TabIndex = 7;
            this.btnexisting.Text = "Existing Employees";
            this.btnexisting.UseVisualStyleBackColor = false;
            this.btnexisting.Click += new System.EventHandler(this.btnexisting_Click);
            // 
            // lblheading
            // 
            this.lblheading.AutoSize = true;
            this.lblheading.BackColor = System.Drawing.Color.Gold;
            this.lblheading.Font = new System.Drawing.Font("Rockwell", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblheading.Location = new System.Drawing.Point(145, 36);
            this.lblheading.Name = "lblheading";
            this.lblheading.Size = new System.Drawing.Size(530, 43);
            this.lblheading.TabIndex = 8;
            this.lblheading.Text = "Human Resource Department";
            // 
            // hrdept
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Snow;
            this.BackgroundImage = global::Employee_System.Properties.Resources.istockphoto_1387809317_612x612;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblheading);
            this.Controls.Add(this.btnexisting);
            this.Controls.Add(this.btnnewemployee);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnexit);
            this.Name = "hrdept";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Human Resource Department";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnexit;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnnewemployee;
        private System.Windows.Forms.Button btnexisting;
        private System.Windows.Forms.Label lblheading;
    }
}