﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Employee_System
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //Check the username & password
            if (txtUser.Text == "Jayan" && txtPassword.Text == "jp0609")
            {
                //Display welcome message
                MessageBox.Show("Welcome " + txtUser.Text + "!", "Login Form", MessageBoxButtons.OK, MessageBoxIcon.Information);

                frm_main newmain = new frm_main();
                this.Hide();
                newmain.Show();
            }
            

            else

            {
                //Display error message
                MessageBox.Show("Invalid Username or Password !", "Login Form", MessageBoxButtons.OK, MessageBoxIcon.Error);
                //Select the UID
                txtUser.Focus();
                txtUser.SelectAll();
                //Clear password
                txtPassword.Clear();
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            
        }

        private void lblExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
