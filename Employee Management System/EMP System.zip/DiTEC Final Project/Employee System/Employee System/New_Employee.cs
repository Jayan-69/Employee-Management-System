﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Employee_System
{
    public partial class Existing_Employee : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-EHGU5T7\SQLEXPRESS;Initial Catalog=Emp_Details;Integrated Security=True"); 

        SqlDataAdapter adapter = new SqlDataAdapter();
        BindingSource bs = new BindingSource();
        SqlDataReader reader;
        public Existing_Employee()
        {
            InitializeComponent();
        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            hrdept newhr = new hrdept();
            this.Hide();
            newhr.Show();
        }

        private void btnMain_Click(object sender, EventArgs e)
        {
            frm_main newmain = new frm_main();
            this.Hide();
            newmain.Show();
        }

        private void btnshow_Click(object sender, EventArgs e)
        {
            try
            {
                String eid = txteid.Text;
                con.Open();
                String stmt = "SELECT * FROM EmpHrDetails WHERE EmpId='" + eid + "'";
                SqlCommand cmd = new SqlCommand(stmt, con);
                reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    txteid.Text = reader[0].ToString();
                    txtfname.Text = reader[1].ToString();
                    txtlname.Text = reader[2].ToString();
                    dtpDOB.Text = reader[3].ToString();
                    txtage.Text = reader[4].ToString();
                    txttpno.Text = reader[5].ToString();
                    txtaddress.Text = reader[6].ToString();
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                String eid = txteid.Text;
                String fname = txtfname.Text;
                String lname = txtlname.Text;
                String dob = dtpDOB.Text;
                String age = txtage.Text;
                String tpno = txttpno.Text;
                String address = txtaddress.Text;

                String stmt = "UPDATE EmpHrDetails SET EmpId = '"+eid+"',Fname='"+fname+"',Lname='"+lname+"',DoB='" + dob + "',Age="+age+",TpNo="+tpno+",ADDRESS='"+address+"' WHERE EmpId='"+eid+"';";
                SqlCommand cmd = new SqlCommand(stmt,con);
                int r = cmd.ExecuteNonQuery();

                if (r > 0)
                    MessageBox.Show("Employee had been Updated");
                else
                    MessageBox.Show("Employee updating error...!!!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error With: " + ex);

            }
            finally
            {
                con.Close();
            }
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                String eid = txteid.Text;
                String stmt = "DELETE FROM EmpHrDetails WHERE EmpId='" + eid + "';";
                SqlCommand cmd = new SqlCommand(stmt,con);
                int r = cmd.ExecuteNonQuery();

                if (r > 0)
                    MessageBox.Show("Employee Deleted");
                else
                    MessageBox.Show("Employee can't delete");
            }
            catch(SqlException ex)
            {
                MessageBox.Show("There is an error occured with : "+ex);
            }
            finally
            {
                con.Close();
            }
        }

        private void btnshowdgv_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                adapter.SelectCommand = new SqlCommand("SELECT * FROM EMpHrDetails", con);
                DataSet ds = new DataSet();
                DataTable dt = new DataTable();
                bs.Clear();
                adapter.Fill(ds);
                dataGridView1.DataSource = ds.Tables[0];

                bs.DataSource = ds.Tables[0];
            }
            catch(SqlException ex)
            {
                MessageBox.Show("There is an error occured with : " + ex);
            }
            finally
            {
                con.Close();
            }
        }
        public void position()
        {
            dataGridView1.Rows[bs.Position].Selected = true;
        }

        private void btnnext_Click(object sender, EventArgs e)
        {
            dataGridView1.ClearSelection();
            bs.MoveNext();
            position();
        }

        private void btnprev_Click(object sender, EventArgs e)
        {
            dataGridView1.ClearSelection();
            bs.MovePrevious();
            position();
        }

        private void btnfirst_Click(object sender, EventArgs e)
        {
            dataGridView1.ClearSelection();
            bs.MoveFirst();
            position();
        }

        private void btnlast_Click(object sender, EventArgs e)
        {
            dataGridView1.ClearSelection();
            bs.MoveLast();
            position();
        }

        private void Existing_Employee_Load(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }
    }
}
