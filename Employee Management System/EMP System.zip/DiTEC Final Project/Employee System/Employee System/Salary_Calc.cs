﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Employee_System
{
    public partial class Salary_Calc : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-EHGU5T7\SQLEXPRESS;Initial Catalog=Emp_Details;Integrated Security=True");
        SqlDataAdapter adapter = new SqlDataAdapter();
        SqlDataReader reader;
        BindingSource bs = new BindingSource();
        public Salary_Calc()
        {
            InitializeComponent();
        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnsaldept_Click(object sender, EventArgs e)
        {
            sal_dept newDepartment = new sal_dept();
            this.Hide();
            newDepartment.Show();
        }

        private void btnmain_Click(object sender, EventArgs e)
        {
            frm_main newmainmenu = new frm_main();
            this.Hide();
            newmainmenu.Show();
        }

        private void btncalculator_Click(object sender, EventArgs e)
        {
            String id = txtid.Text;
            String month = txtmonth.Text;
            try
            {
                con.Open();
                String Stmt = "SELECT Salary FROM SalaryDetails WHERE EmpId = '" + id + "' AND Month = '" + month + "';";

                SqlCommand cmd = new SqlCommand(Stmt, con);

                reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    lblsalary.Text = "Your Salary is : " + reader[0].ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }

        }

        private void Salary_Calc_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            adapter.SelectCommand = new SqlCommand("SELECT * FROM SalaryDetails",con);
            bs.Clear();
            DataSet ds = new DataSet();
            adapter.Fill(ds);
            dgv1.DataSource = ds.Tables[0];
            bs.DataSource = ds.Tables[0];

        }
        public void positions()
        {
            dgv1.Rows[bs.Position].Selected = true;
        }

        private void btnnext_Click(object sender, EventArgs e)
        {
            dgv1.ClearSelection();
            bs.MoveNext();
            positions();
        }

        private void btnprev_Click(object sender, EventArgs e)
        {
            dgv1.ClearSelection();
            bs.MovePrevious();
            positions();
        }

        private void btnfirst_Click(object sender, EventArgs e)
        {
            dgv1.ClearSelection();
            bs.MoveFirst();
            positions();
        }

        private void btnlast_Click(object sender, EventArgs e)
        {
            dgv1.ClearSelection();
            bs.MoveLast();
            positions();
        }

        private void dgv1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void lblsalary_Click(object sender, EventArgs e)
        {

        }
    }
}
