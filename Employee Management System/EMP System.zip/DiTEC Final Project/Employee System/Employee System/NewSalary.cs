﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Employee_System
{
    public partial class NewSalary : Form 
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-EHGU5T7\SQLEXPRESS;Initial Catalog=Emp_Details;Integrated Security=True");
        SqlDataAdapter adapter = new SqlDataAdapter();  

        public NewSalary()
        {
            InitializeComponent();
        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnsaldept_Click(object sender, EventArgs e)
        {
            sal_dept newDepartment = new sal_dept();
            this.Hide();
            newDepartment.Show();
        }

        private void btnmain_Click(object sender, EventArgs e)
        {
            frm_main newmainmenu = new frm_main();
            this.Hide();
            newmainmenu.Show();
        }

        private void btninsert_Click(object sender, EventArgs e)
        {
            try {
                con.Open();
                int wh = int.Parse(txtwh.Text);
                int whr = int.Parse(txtwhr.Text);
                int ot = int.Parse(txtot.Text);
                int otr = int.Parse(txtotrate.Text);

                int sal = wh * whr + ot * otr;


                adapter.InsertCommand = new SqlCommand("INSERT INTO SalaryDetails VALUES(@empid,@month,@WHours,@WRate,@OTHours,@OTRate,@Salary)", con);
                adapter.InsertCommand.Parameters.Add("@empid",SqlDbType.VarChar).Value = txtid.Text ;
                adapter.InsertCommand.Parameters.Add("@month", SqlDbType.VarChar).Value = txtmonth.Text;
                adapter.InsertCommand.Parameters.Add("@WHours", SqlDbType.Int).Value = int.Parse(txtwh.Text);
                adapter.InsertCommand.Parameters.Add("@WRate", SqlDbType.Int).Value = int.Parse(txtwhr.Text);
                adapter.InsertCommand.Parameters.Add("@OTHours", SqlDbType.Int).Value = int.Parse(txtot.Text);
                adapter.InsertCommand.Parameters.Add("@OTRate", SqlDbType.VarChar).Value = int.Parse(txtotrate.Text);
                adapter.InsertCommand.Parameters.Add("@Salary", SqlDbType.Int).Value = sal;

               
                int r = adapter.InsertCommand.ExecuteNonQuery();
               

                if (r > 0)
                    MessageBox.Show("Data has been added");
                else
                    MessageBox.Show("Data has not added");
            }
            catch(SqlException ex) {
                MessageBox.Show("Your error is : " + ex);

            }
            finally
            {
                con.Close();
            }
        }

        private void NewSalary_Load(object sender, EventArgs e)
        {

        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            txtid.Text = "";
            txtwh.Text = "";
            txtmonth.Text = "";
            txtot.Text = "";
            txtwhr.Text = "";
            txtotrate.Text = "";

        }
    }
}
