﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Employee_System
{
    public partial class sal_dept : Form
    {
        public sal_dept()
        {
            InitializeComponent();
        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnMainMenu_Click(object sender, EventArgs e)
        {
            frm_main newmainmenu = new frm_main();
            this.Hide();
            newmainmenu.Show();
        }

        private void btnAddNew_Click(object sender, EventArgs e)
        {
            NewSalary newsalary = new NewSalary();
            this.Hide();
            newsalary.Show();
        }

        private void btnsalcal_Click(object sender, EventArgs e)
        {
            Salary_Calc newcalculator = new Salary_Calc();
            this.Hide();
            newcalculator.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            UpdateorDelete newud = new UpdateorDelete();
            this.Hide();
            newud.Show();
        }

        private void sal_dept_Load(object sender, EventArgs e)
        {

        }
    }
}
