﻿namespace Employee_System
{
    partial class Salary_Calc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnsaldept = new System.Windows.Forms.Button();
            this.btnexit = new System.Windows.Forms.Button();
            this.btnmain = new System.Windows.Forms.Button();
            this.lblid = new System.Windows.Forms.Label();
            this.lblmonth = new System.Windows.Forms.Label();
            this.txtid = new System.Windows.Forms.TextBox();
            this.txtmonth = new System.Windows.Forms.TextBox();
            this.btncalculator = new System.Windows.Forms.Button();
            this.lblsalary = new System.Windows.Forms.Label();
            this.dgv1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.lblheading = new System.Windows.Forms.Label();
            this.btnlast = new System.Windows.Forms.Button();
            this.btnfirst = new System.Windows.Forms.Button();
            this.btnprev = new System.Windows.Forms.Button();
            this.btnnext = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnsaldept
            // 
            this.btnsaldept.BackColor = System.Drawing.Color.Blue;
            this.btnsaldept.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnsaldept.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnsaldept.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsaldept.ForeColor = System.Drawing.Color.Snow;
            this.btnsaldept.Location = new System.Drawing.Point(104, 421);
            this.btnsaldept.Name = "btnsaldept";
            this.btnsaldept.Size = new System.Drawing.Size(157, 41);
            this.btnsaldept.TabIndex = 5;
            this.btnsaldept.Text = "Salary Dept";
            this.btnsaldept.UseVisualStyleBackColor = false;
            this.btnsaldept.Click += new System.EventHandler(this.btnsaldept_Click);
            // 
            // btnexit
            // 
            this.btnexit.BackColor = System.Drawing.Color.Red;
            this.btnexit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnexit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnexit.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnexit.ForeColor = System.Drawing.Color.Snow;
            this.btnexit.Location = new System.Drawing.Point(713, 422);
            this.btnexit.Name = "btnexit";
            this.btnexit.Size = new System.Drawing.Size(157, 40);
            this.btnexit.TabIndex = 4;
            this.btnexit.Text = "Exit";
            this.btnexit.UseVisualStyleBackColor = false;
            this.btnexit.Click += new System.EventHandler(this.btnexit_Click);
            // 
            // btnmain
            // 
            this.btnmain.BackColor = System.Drawing.Color.Blue;
            this.btnmain.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnmain.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnmain.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmain.ForeColor = System.Drawing.Color.Snow;
            this.btnmain.Location = new System.Drawing.Point(401, 422);
            this.btnmain.Name = "btnmain";
            this.btnmain.Size = new System.Drawing.Size(157, 41);
            this.btnmain.TabIndex = 3;
            this.btnmain.Text = "Main Menu";
            this.btnmain.UseVisualStyleBackColor = false;
            this.btnmain.Click += new System.EventHandler(this.btnmain_Click);
            // 
            // lblid
            // 
            this.lblid.AutoSize = true;
            this.lblid.BackColor = System.Drawing.Color.Cyan;
            this.lblid.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblid.ForeColor = System.Drawing.Color.Black;
            this.lblid.Location = new System.Drawing.Point(88, 125);
            this.lblid.Name = "lblid";
            this.lblid.Size = new System.Drawing.Size(127, 24);
            this.lblid.TabIndex = 6;
            this.lblid.Text = "Employee Id";
            // 
            // lblmonth
            // 
            this.lblmonth.AutoSize = true;
            this.lblmonth.BackColor = System.Drawing.Color.Cyan;
            this.lblmonth.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmonth.ForeColor = System.Drawing.Color.Black;
            this.lblmonth.Location = new System.Drawing.Point(88, 174);
            this.lblmonth.Name = "lblmonth";
            this.lblmonth.Size = new System.Drawing.Size(68, 24);
            this.lblmonth.TabIndex = 7;
            this.lblmonth.Text = "Month";
            // 
            // txtid
            // 
            this.txtid.BackColor = System.Drawing.Color.Snow;
            this.txtid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtid.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtid.Location = new System.Drawing.Point(266, 125);
            this.txtid.Name = "txtid";
            this.txtid.Size = new System.Drawing.Size(144, 22);
            this.txtid.TabIndex = 8;
            // 
            // txtmonth
            // 
            this.txtmonth.BackColor = System.Drawing.Color.Snow;
            this.txtmonth.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtmonth.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmonth.Location = new System.Drawing.Point(266, 174);
            this.txtmonth.Name = "txtmonth";
            this.txtmonth.Size = new System.Drawing.Size(144, 22);
            this.txtmonth.TabIndex = 9;
            // 
            // btncalculator
            // 
            this.btncalculator.BackColor = System.Drawing.Color.Blue;
            this.btncalculator.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btncalculator.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btncalculator.Font = new System.Drawing.Font("MS Reference Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncalculator.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btncalculator.Location = new System.Drawing.Point(104, 233);
            this.btncalculator.Name = "btncalculator";
            this.btncalculator.Size = new System.Drawing.Size(252, 35);
            this.btncalculator.TabIndex = 10;
            this.btncalculator.Text = "Calculate Salary";
            this.btncalculator.UseVisualStyleBackColor = false;
            this.btncalculator.Click += new System.EventHandler(this.btncalculator_Click);
            // 
            // lblsalary
            // 
            this.lblsalary.AutoSize = true;
            this.lblsalary.BackColor = System.Drawing.Color.Gold;
            this.lblsalary.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsalary.ForeColor = System.Drawing.Color.Black;
            this.lblsalary.Location = new System.Drawing.Point(41, 303);
            this.lblsalary.Name = "lblsalary";
            this.lblsalary.Size = new System.Drawing.Size(393, 31);
            this.lblsalary.TabIndex = 11;
            this.lblsalary.Text = "Your Salary Will Appear Here";
            this.lblsalary.Click += new System.EventHandler(this.lblsalary_Click);
            // 
            // dgv1
            // 
            this.dgv1.BackgroundColor = System.Drawing.Color.Snow;
            this.dgv1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgv1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv1.GridColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dgv1.Location = new System.Drawing.Point(464, 149);
            this.dgv1.Name = "dgv1";
            this.dgv1.Size = new System.Drawing.Size(376, 185);
            this.dgv1.TabIndex = 12;
            this.dgv1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv1_CellContentClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Gold;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(493, 106);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(313, 25);
            this.label1.TabIndex = 13;
            this.label1.Text = "Show All Salary Informations";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Lime;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(527, 345);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(252, 35);
            this.button1.TabIndex = 14;
            this.button1.Text = "Show Informations";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblheading
            // 
            this.lblheading.AutoSize = true;
            this.lblheading.BackColor = System.Drawing.Color.Gold;
            this.lblheading.Font = new System.Drawing.Font("Elephant", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblheading.ForeColor = System.Drawing.Color.Black;
            this.lblheading.Location = new System.Drawing.Point(331, 32);
            this.lblheading.Name = "lblheading";
            this.lblheading.Size = new System.Drawing.Size(338, 45);
            this.lblheading.TabIndex = 15;
            this.lblheading.Text = "Find Your Salary";
            // 
            // btnlast
            // 
            this.btnlast.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnlast.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnlast.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnlast.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnlast.Location = new System.Drawing.Point(846, 293);
            this.btnlast.Name = "btnlast";
            this.btnlast.Size = new System.Drawing.Size(110, 41);
            this.btnlast.TabIndex = 32;
            this.btnlast.Text = "Last Employee";
            this.btnlast.UseVisualStyleBackColor = false;
            this.btnlast.Click += new System.EventHandler(this.btnlast_Click);
            // 
            // btnfirst
            // 
            this.btnfirst.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnfirst.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnfirst.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnfirst.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnfirst.Location = new System.Drawing.Point(846, 239);
            this.btnfirst.Name = "btnfirst";
            this.btnfirst.Size = new System.Drawing.Size(110, 48);
            this.btnfirst.TabIndex = 31;
            this.btnfirst.Text = "First Employee";
            this.btnfirst.UseVisualStyleBackColor = false;
            this.btnfirst.Click += new System.EventHandler(this.btnfirst_Click);
            // 
            // btnprev
            // 
            this.btnprev.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnprev.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnprev.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnprev.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnprev.Location = new System.Drawing.Point(846, 191);
            this.btnprev.Name = "btnprev";
            this.btnprev.Size = new System.Drawing.Size(110, 42);
            this.btnprev.TabIndex = 30;
            this.btnprev.Text = "Previous";
            this.btnprev.UseVisualStyleBackColor = false;
            this.btnprev.Click += new System.EventHandler(this.btnprev_Click);
            // 
            // btnnext
            // 
            this.btnnext.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnnext.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnnext.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnnext.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnnext.Location = new System.Drawing.Point(846, 149);
            this.btnnext.Name = "btnnext";
            this.btnnext.Size = new System.Drawing.Size(110, 39);
            this.btnnext.TabIndex = 29;
            this.btnnext.Text = "Next";
            this.btnnext.UseVisualStyleBackColor = false;
            this.btnnext.Click += new System.EventHandler(this.btnnext_Click);
            // 
            // Salary_Calc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Snow;
            this.BackgroundImage = global::Employee_System.Properties.Resources.istockphoto_1387809317_612x612;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(987, 486);
            this.Controls.Add(this.btnlast);
            this.Controls.Add(this.btnfirst);
            this.Controls.Add(this.btnprev);
            this.Controls.Add(this.btnnext);
            this.Controls.Add(this.lblheading);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgv1);
            this.Controls.Add(this.lblsalary);
            this.Controls.Add(this.btncalculator);
            this.Controls.Add(this.txtmonth);
            this.Controls.Add(this.txtid);
            this.Controls.Add(this.lblmonth);
            this.Controls.Add(this.lblid);
            this.Controls.Add(this.btnsaldept);
            this.Controls.Add(this.btnexit);
            this.Controls.Add(this.btnmain);
            this.Name = "Salary_Calc";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Salary Calculate";
            this.Load += new System.EventHandler(this.Salary_Calc_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnsaldept;
        private System.Windows.Forms.Button btnexit;
        private System.Windows.Forms.Button btnmain;
        private System.Windows.Forms.Label lblid;
        private System.Windows.Forms.Label lblmonth;
        private System.Windows.Forms.TextBox txtid;
        private System.Windows.Forms.TextBox txtmonth;
        private System.Windows.Forms.Button btncalculator;
        private System.Windows.Forms.Label lblsalary;
        private System.Windows.Forms.DataGridView dgv1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lblheading;
        private System.Windows.Forms.Button btnlast;
        private System.Windows.Forms.Button btnfirst;
        private System.Windows.Forms.Button btnprev;
        private System.Windows.Forms.Button btnnext;
    }
}