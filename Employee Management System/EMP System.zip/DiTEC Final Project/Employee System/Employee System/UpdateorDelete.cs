﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Employee_System
{
    public partial class UpdateorDelete : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-EHGU5T7\SQLEXPRESS;Initial Catalog=Emp_Details;Integrated Security=True");
        SqlDataAdapter adapter = new SqlDataAdapter();
        BindingSource bs = new BindingSource();
        SqlDataReader reader;
        public UpdateorDelete()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                String stmt = "UPDATE SalaryDetails SET Month='"+txtmonth.Text+"',W_Hours="+txtwh.Text+",W_Rate="+txtwhr.Text+",OT_Hours="+txtot.Text+",OT_Rate="+txtotrate.Text+" WHERE EmpId='"+txtid.Text+"';";
                SqlCommand cmd = new SqlCommand(stmt,con);
                int r = cmd.ExecuteNonQuery();

                if (r > 0)
                    MessageBox.Show("Data has been updated");
                else
                    MessageBox.Show("Data has not Updated.....!!!!!");
            }catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            sal_dept newSalary = new sal_dept();
            this.Hide();
            newSalary.Show();
        }

        private void btnMain_Click(object sender, EventArgs e)
        {
            frm_main newmain = new frm_main();
            this.Hide();
            newmain.Show();
        }

        private void btninsert_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                String stmt = "DELETE SalaryDetails WHERE EmpId = '"+txtid.Text+"'";
                SqlCommand cmd = new SqlCommand(stmt,con);
                int r = cmd.ExecuteNonQuery();

                if (r > 0)
                    MessageBox.Show("Employee Salary Informations had been Deleted Successfully.");
                else
                    MessageBox.Show("Employee Salary Informations had not been Deleted Successfully......!!!!!");
            }
            catch(Exception ex)
            {
                MessageBox.Show("An Error occurd With : "+ex);

            }
            finally
            {
                con.Close();
            }
        }
    }
}
