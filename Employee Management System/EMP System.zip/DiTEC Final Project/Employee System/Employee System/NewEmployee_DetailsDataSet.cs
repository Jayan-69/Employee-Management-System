﻿namespace Employee_System
{


    partial class NewEmployee_DetailsDataSet
    {
    }
}
