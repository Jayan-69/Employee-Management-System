﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Employee_System
{
    
    public partial class NewEmployeeAdding : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-EHGU5T7\SQLEXPRESS;Initial Catalog=Emp_Details;Integrated Security=True");
        SqlDataAdapter adapter = new SqlDataAdapter();
        SqlDataReader reader;  
        public NewEmployeeAdding()
        {
            InitializeComponent();
        }

        private void btnaddnew_Click(object sender, EventArgs e)
        {
            try
            {
                adapter.InsertCommand = new SqlCommand("INSERT INTO EmpHrDetails VALUES(@eid,@fname,@lname,@DoB,@Age,@TpNo,@address)", con);
                adapter.InsertCommand.Parameters.Add("@eid", SqlDbType.VarChar).Value = txtid.Text;
                adapter.InsertCommand.Parameters.Add("@fname", SqlDbType.VarChar).Value = txtfname.Text;
                adapter.InsertCommand.Parameters.Add("@lname", SqlDbType.VarChar).Value = txtlname.Text;
                adapter.InsertCommand.Parameters.Add("@DoB", SqlDbType.Date).Value = dtpDOB.Text; 
                adapter.InsertCommand.Parameters.Add("@Age", SqlDbType.Int).Value = int.Parse(txtage.Text);
                adapter.InsertCommand.Parameters.Add("@tpNo", SqlDbType.Int).Value = int.Parse(txttpno.Text);
                adapter.InsertCommand.Parameters.Add("@address", SqlDbType.VarChar).Value = txtadd.Text;

                con.Open();
                int r = adapter.InsertCommand.ExecuteNonQuery();
                

                if (r > 0)
                    MessageBox.Show("Employee added to the database");
                else
                    MessageBox.Show("Employee not added please Check the connection");
            }
            catch(Exception ex)
            {
                MessageBox.Show("You have an error with:  "+ex);
            }
            finally
            {
                con.Close();
            }
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void NewEmployeeAdding_Load(object sender, EventArgs e)
        {

        }

        private void btnshow_Click(object sender, EventArgs e)
        {
           

           }

        private void btnclear_Click(object sender, EventArgs e)
        {
            txtadd.Clear();
            txtage.Clear();
         
            txtfname.Clear();
            txtid.Clear();
            txtlname.Clear();
            txttpno.Clear();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            hrdept newhr = new hrdept();
            this.Hide();
            newhr.Show();
        }

        private void btbExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
